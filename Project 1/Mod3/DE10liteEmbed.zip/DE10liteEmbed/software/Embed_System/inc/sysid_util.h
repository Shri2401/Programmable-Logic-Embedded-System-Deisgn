#ifndef SYSID_UTIL_H_
#define SYSID_UTIL_H_

#include <stdio.h>
#include "alt_types.h"
#include "system.h"
#include "altera_avalon_sysid_regs.h"

// function prototypes from src/sysid_util.c
void display_sysid (void);

#endif /*UART_UTIL_H_*/

